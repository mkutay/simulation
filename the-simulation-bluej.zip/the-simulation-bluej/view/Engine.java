package view;

import entities.generic.Entity;
import graphics.Display;
import simulation.environment.Environment;
import simulation.Simulator;
import simulation.environment.Weather;
import simulation.simulationData.Data;

import java.awt.*;
import java.util.List;
import java.util.HashMap;

/**
 * Combines the Simulator and Display to visualise the simulation.
 * This is the "engine" that runs the entire simulation.
 * 
 * @author Anas Ahmed and Mehmet Kutay Bozkurt
 * @version 1.0
 */
public class Engine {
  private final Display display; // The GUI display
  private final Simulator simulator; // The simulation
  private final Clock clock; // Clock to keep track of time
  private boolean running = false; // Whether the simulation is running

  /**
   * 0 < scaleFactor < 1 => field is zoomed in
   * scaleFactor = 1 => field is screen size (1 field unit = 1px)
   * scale factor > 1 => field is zoomed out
   */
  private final double fieldScaleFactor; // Scales the field size up/down, so field size doesn't have to be screen size

    /**
   * Constructor - Create an engine to run the simulation.
   * @param displayWidth The width of the GUI display.
   * @param displayHeight The height of the GUI display.
   * @param fps FPS to run the simulation at.
   */
  public Engine(int displayWidth, int displayHeight, int fps) {
    fieldScaleFactor = Data.getFieldScaleFactor();
    int fieldWidth = (int) (displayWidth * fieldScaleFactor);
    int fieldHeight = (int) (displayHeight * fieldScaleFactor);

    simulator = new Simulator(fieldWidth, fieldHeight);
    display = new Display(displayWidth, displayHeight);
    clock = new Clock(fps);
  }

  /**
   * Main loop of the simulation.
   */
  private void run() {
    while (running) {
      simulator.step();

      display.fill(Color.BLACK);

      List<Entity> entities = simulator.getField().getAllEntities();
      // We draw the entities in order of oldest to youngest to prevent annoying overlap.
      for (int i = entities.size() - 1; i >= 0; i--) {
        Entity entity = entities.get(i);
        entity.draw(display, fieldScaleFactor);
      }


      // Debug tool to show the quadtree. It also looks really cool!
      if (Data.getShowQuadTrees()) {
        simulator.getField().getQuadtree().draw(display, fieldScaleFactor);
      }

      // Draw and update weather effects.
      if (Data.getDoWeatherCycle()) {
        updateWeatherEffects(display);
        drawWeatherText();
      }

      drawFieldDataText();

      if (Data.getDoDayNightCycle()) {
        drawTimeText();
      }

      display.update();
      clock.tick();
    }
  }

  /**
   * Update the weather effects on the display.
   * @param display The display to update the weather effects on.
   */
  private void updateWeatherEffects(Display display) {
    Environment environment = simulator.getField().environment;
    environment.spawnRain(display);
    environment.drawScreenEffects(display);
    environment.spawnLightning(display);
    environment.updateWeatherEffects(display);
  }

  /**
   * Draws the weather text, specifying the current weather and wind direction.
   */
  private void drawWeatherText() {
    Weather weather = simulator.getField().environment.getWeather();
    display.drawText(weather.toString(), 20, 5, 40, Color.WHITE);
    if (weather == Weather.WINDY || weather == Weather.STORM) {
      display.drawText("Wind Direction:", 20, 5, 60, Color.WHITE);
      double windDirection = simulator.getField().environment.getWindDirection();
      display.drawCircle(180, 55, 20, Color.BLACK);
      display.drawArrow(180, 55, windDirection, 20, Color.WHITE);
    }
  }

  /**
   * Renders text of the current time of day.
   */
  private void drawTimeText() {
    String time = simulator.getField().environment.getTimeFormatted();
    display.drawText(time, 20, 5, 20, Color.WHITE);
  }

  /**
   * Lists all alive entities and the number of existing entities for each species
   * in the bottom left corner.
   */
  private void drawFieldDataText() {
    HashMap<String, Integer> fieldData = simulator.getFieldData();
    int fontSize = 15;
    int startY = (display.getHeight() - fieldData.size() * fontSize);
    int i = 0;
    for (String entityName : fieldData.keySet()) {
      String data = entityName + ": " + fieldData.get(entityName);
      display.drawText(data, fontSize, 5, startY + i * fontSize, Color.WHITE);
      i++;
    }
  }

  /**
   * Start simulation asynchronously on a new thread so that it can be
   * stopped in the main execution thread.
   */
  public void start() {
    running = true;
    Thread t = new Thread(this::run);
    t.start();
  }
}
